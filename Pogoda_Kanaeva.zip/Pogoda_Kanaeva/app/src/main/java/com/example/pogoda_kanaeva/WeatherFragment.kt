package com.example.pogoda_kanaeva

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.net.URLEncoder

class WeatherFragment : Fragment() {

    private val apiKey = "49da4bb0f9966e7669deac043cdb2dd7"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Подключаем разметку
        val view = inflater.inflate(R.layout.fragment_weather, container, false)

        // Находим элементы через view.
        val cityInput = view.findViewById<EditText>(R.id.cityInput)
        val searchButton = view.findViewById<Button>(R.id.searchButton)
        val tvCity = view.findViewById<TextView>(R.id.tvCity)
        val tvTemp = view.findViewById<TextView>(R.id.tvTemp)
        val tvPressure = view.findViewById<TextView>(R.id.tvPressure)
        val tvWind = view.findViewById<TextView>(R.id.tvWind)

        searchButton.setOnClickListener {
            val city = cityInput.text.toString().trim()
            if (city.isNotEmpty()) {
                getWeather(city, tvCity, tvTemp, tvPressure, tvWind)
            } else {
                Toast.makeText(requireContext(), "Введите название города", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun getWeather(city: String, tvCity: TextView, tvTemp: TextView, tvPressure: TextView, tvWind: TextView) {
        val encodedCity = URLEncoder.encode(city, "UTF-8")
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$encodedCity&appid=$apiKey&units=metric&lang=ru"

        // Используем requireContext() вместо this
        val queue = Volley.newRequestQueue(requireContext())

        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                try {
                    val obj = JSONObject(response)
                    val name = obj.getString("name")
                    val mainObj = obj.getJSONObject("main")
                    val temp = mainObj.getDouble("temp")
                    val pressure = mainObj.getDouble("pressure")
                    val windObj = obj.getJSONObject("wind")
                    val windSpeed = windObj.getDouble("speed")

                    Log.d("MyLog", "Город: $name, Температура: $temp")

                    tvCity.text = "Город: $name"
                    tvTemp.text = "Температура: $temp °C"
                    tvPressure.text = "Давление: ${(pressure / 1.333).toInt()} мм рт. ст."
                    tvWind.text = "Ветер: $windSpeed м/с"
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(requireContext(), "Ошибка при чтении данных", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                val code = error.networkResponse?.statusCode
                Log.e("MyLog", "Ошибка: код $code, ${error.message}")

                val message = when (code) {
                    401 -> "Неверный API-ключ"
                    404 -> "Город не найден (попробуйте написать на английском)"
                    429 -> "Слишком много запросов, попробуйте позже"
                    else -> "Ошибка сети, попробуйте ещё раз"
                }
                Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
            }
        )
        queue.add(stringRequest)
    }
}